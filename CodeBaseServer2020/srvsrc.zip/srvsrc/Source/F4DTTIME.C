/* f4dttime.c (c)Copyright Sequiter Software Inc., 1988-2001.  All rights reserved. */
/* date/time field manipulation */

#include "d4all.h"
#ifndef S4UNIX
   #ifdef __TURBOC__
      #pragma hdrstop
   #endif
#endif

/* contents have been moved to f4field.c for now at least */
